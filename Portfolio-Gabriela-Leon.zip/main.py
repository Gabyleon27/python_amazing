from flask import Flask,render_template #import flask
app = Flask('app') #app Flask

#REST endpoints:

#function to render the home page
@app.route('/')
def home():
  return render_template("theme-particle.html")

@app.route('/python')
def python():
  return render_template("python.html")
#run the host and port
app.run(host='0.0.0.0', port=8080)